# Springboard data science taster course notebooks

## worked_notebooks
Contain the worked example notebooks that include completed code.

## source_notebooks
These are sourced from worked_notebooks but have had the assignment
code deleted and output cleared.
Students will load these notebooks and work from them. They can, if
and when they choose, refer to the original notebooks in worked_notebooks
to check their answers or get unstuck.

# About me
Hi, I'm Guy. I'm a mentor with Springboard and really hope you find this taste
of learning data scientist is something you'd like more of. If you have any
questions, or are thinking of signing up to take things further with
Springboard's full courses, then drop me a line. I'll be happy to help.

# Yelp dataset
Note, these exercises were put together using Round 12 of Yelp's
challenge. Currently Yelp are on round 13. I haven't revisited the exercises
using the newer dataset. I hope you still get sensible answers, but let
me know if this causes you any difficulties. If you'd like the original
dataset (from round 12) let me know. If this option is popular I may
devote some of my Google drive to hosting it.
